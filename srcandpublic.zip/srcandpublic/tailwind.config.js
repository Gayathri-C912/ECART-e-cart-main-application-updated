module.exports = {
  content: ["./src/**/*.{html,js,jsx,tsx,ts}"],
  theme: {
    extend: {
      backgroundImage: {
        "singleBg": "url('/src/assets/bg-single.jpg')", // Corrected the path
      },
      fontFamily: {
        poppins: ["Poppins", "sans-serif"],
      },
    },
    screens: {
      'xs': '480px',  // Example of adding a custom breakpoint
    },
    keyframes: {
      rotate: {
        '0%': { transform: 'rotate(0deg)' },
        '100%': { transform: 'rotate(360deg)' },
      },
      move: {
        //'0%': { transform: 'translateX(0)' },
        '50%': { transform: 'translateX(50px)' },
        '100%': { transform: 'translateX(0)' },
      },
      animation: {
        fade: 'fade 8s ease-in-out infinite',
      },
    },
    animation: {
      rotate: 'rotate 10s linear infinite',
      move: 'move 5s ease-in-out infinite',
    },
  },
  backgroundSize: {
    '90-auto': '90% auto', // Custom background size utility
  },
  
  plugins: [],
}


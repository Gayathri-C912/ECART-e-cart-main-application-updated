export const api = `https://dummyjson.com/products`;

// export const api =`https://63aa73707d7edb3ae628645c.mockapi.io/students`;

// export const api = `https://apimocha.com/ecart/products`;
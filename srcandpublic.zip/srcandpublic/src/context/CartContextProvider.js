import React, {useState, useEffect } from "react";
import { createContext } from "react";

export const CartContext = createContext({});
const CartContextProvider = ({ children }) => {

  const [cartItems, setCartItems] = useState(() => {
    const savedCart = localStorage.getItem('cartItems');
    return savedCart ? JSON.parse(savedCart) : [
      {
        id: "",
        title: "",
        price: 0,
        images: [],
        quantity: 1,
        discount: 0,
        description: "",
      },
    ];
  });

  useEffect(() => {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  }, [cartItems]);


  //productwise quantity
  //total qunatity
  const handleDecreaseQuantity = (id) => {
    // cartItems already has the id of the product and quantity
    setCartItems(
      cartItems.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity - 1 } : item
      )
    );
  };
  const handleIncreaseQuantity = (id) => {
    setCartItems(
      cartItems.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity + 1 } : item
      )
    );
  };
  const [showModal, setShowModal] = useState(false);

  const handleBag =({product}) =>
    {
      //console.log("modal");
      setShowModal(true);
      //const storedCartItems = getCartFromLocalStorage();
      const existingItem = cartItems.find((item) => item.id === product.id);
  
      if (existingItem) {
        setCartItems((prev) =>
          prev.map((item) =>
            item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
          )
        );
      } else {
        setCartItems((prev) => [
          ...prev,
          {
            id: product.id,
            title: product.title,
            price: product.price,
            images: product.images,
            quantity: 1,
            description: product.description,
          },
        ]);
      }
    }

    

  return (
    <CartContext.Provider
      value={{
        cartItems,
        setCartItems,
        showModal,
        setShowModal,
        handleDecreaseQuantity,
        handleIncreaseQuantity,
        handleBag
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export default CartContextProvider;

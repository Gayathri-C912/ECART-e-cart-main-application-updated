import React, { useContext } from 'react';
import { CartContext } from '../../../context/CartContextProvider';
import ListOfCartItems from '.';


const CartIcon = () => {

    const {setShowModal} = useContext(CartContext);

    const handleCartIconClick = () => {
        setShowModal(true);
      };

  return (
    <div>
         <button  className="text-gray-800 hover:text-blue-600 text-xl p-2 flex justify-end" onClick={handleCartIconClick}>
      <i className="fa fa-shopping-cart" aria-hidden="true"></i> {/* Font Awesome icon */}
    </button>
    <ListOfCartItems />
    </div>
  );
};

export default CartIcon;

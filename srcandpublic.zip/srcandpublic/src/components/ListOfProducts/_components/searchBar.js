import React, { useState } from 'react';

function SearchBar({ onSearch }) {
  const [query, setQuery] = useState('');

  const handleChange = (event) => {
    setQuery(event.target.value);
    console.log('Input Value:', event.target.value); 
    onSearch(event.target.value);
  };

  const handleClear = () => {
    setQuery('');
    onSearch(''); // Clear the search results
  };

  return (
    <div className="flex justify-center mb-4">
      <input
        type="text"
        value={query}
        onChange={handleChange}
        placeholder="Search products..."
        className="border border-gray-300 rounded-lg p-2 w-full max-w-md"
      />
      {query && (
        <button
          type="button"
          onClick={handleClear}
          className="ml-2 p-2 bg-gray-200 rounded-lg text-gray-600 hover:bg-gray-300"
        >
          Clear
        </button>
      )}
    </div>
  );
}

export default SearchBar;

import React, { useState, useEffect } from "react";
import { api } from "../../api/endpoints";
import ProductItem from "./_components/ProductItem";
import SearchBar from "./_components/searchBar";
import { Link } from "react-router-dom";

const ListOfProducts = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    //to fetch the products at the time of page loading
    handleFetchProducts();
  }, []);

  const handleFetchProducts = async () => {
    // it is promise function, (it will return us data)or (it will return us error),
    const data = await fetch(api +"?limit=10&skip=0&select=title,price,images,rating,description,reviews,category", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    //  to convert the response into json format
    const response = await data.json();
    // updating the state using setProducts
    setProducts(response.products);
    setFilteredProducts(response.products);
  };


  const handleSearch = (query) => {
    console.log('Search Query:', query); 
    //setSearchQuery(query);
    if (query) {
      setFilteredProducts(
        products.filter((product) =>
          product.title.toLowerCase().includes(query.toLowerCase())
        )
      );
    } else {
      setFilteredProducts(products);
    }
  };


  return (
    <section className=" bg-gradient-to-r from-gray-50 via-gray-300 to-gray-100 font-poppins px-5 mx-auto py-5 md:px-10 md:py-10 2xl:container poppins-regular">
      <div className="mb-4">
        <Link to="/" className="px-4 py-2 bg-pink-400 text-white rounded-lg hover:bg-gray-700 transition duration-300 absolute top-10 right-10">
          Home 
        </Link>
      </div>

      <SearchBar onSearch={handleSearch}/>
      <header>
        <h1 className="text-xl text-gray-400 h-16 font-medium mx-auto">
          My Products
        </h1>
      </header>


      <div className="container mx-auto p-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        {filteredProducts.map((product) => {
          return (
            <React.Fragment key={product.id} className="border border-gray-300 rounded-lg overflow-hidden shadow-lg">
              <ProductItem product={product} />
            </React.Fragment>
          ); 
        })}

      </div>
      </div>
    </section>
  );
};

export default ListOfProducts;

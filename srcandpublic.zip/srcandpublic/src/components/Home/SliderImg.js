// ImageSlider.js
import React from 'react';

const images = [
  'https://via.placeholder.com/1600x900?text=Image+1',
  'https://via.placeholder.com/1600x900?text=Image+2',
  'https://via.placeholder.com/1600x900?text=Image+3',
  'https://via.placeholder.com/1600x900?text=Image+4',
];

function ImageSlider() {
  return (
    <div className="relative w-full h-screen overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-full h-full">
          {images.map((image, index) => (
            <div
              key={index}
              className={`absolute w-full h-full bg-cover bg-center transition-opacity duration-1000 ease-in-out ${index === 0 ? 'animate-fade' : ''}`}
              style={{ backgroundImage: `url(${image})`, animationDelay: `${index * 2000}ms` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default ImageSlider;
